package com.commonUtilities;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterTest;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {
public WebDriver driver;
public Properties pro = new Properties();
public String pathOfPropertyFile = System.getProperty("user.dir")+"/src/main/java/com/configurations/Config.properties";

public void callBrowser() throws IOException {
	FileInputStream fileinputstream = new FileInputStream(pathOfPropertyFile);
	pro.load(fileinputstream);
	switch (pro.getProperty("BROWSER")) {
	case "CHROME":
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		getURLAndMaximise(pro.getProperty("URL"));
		break;
	case "FIREFOX":
		WebDriverManager.firefoxdriver().setup();
		driver = new FirefoxDriver();
		getURLAndMaximise(pro.getProperty("URL"));
		break;
	case "EDGE":
		WebDriverManager.edgedriver().setup();
		driver = new EdgeDriver();
		getURLAndMaximise(pro.getProperty("URL"));
		break;
	default:
		WebDriverManager.iedriver().setup();
		driver = new InternetExplorerDriver();
		getURLAndMaximise(pro.getProperty("URL"));
		break;
	}
}

private void getURLAndMaximise(String URL) {
	driver.get(URL);
	driver.manage().deleteAllCookies();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
}
@AfterTest
public void tearDown() {
	if(!(driver==null)) {
		driver.close();
	}
}
}
