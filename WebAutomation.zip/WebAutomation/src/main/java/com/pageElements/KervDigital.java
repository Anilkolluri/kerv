package com.pageElements;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class KervDigital {
	WebDriver driver;
	
	public By AcceptAll_Btn = By.xpath("(//a[contains(text(),'Accept all ')])[1]");
	public By careers_MainLink = By.xpath("(//a[contains(text(),'Careers')])[1]");
	public By JobOpportunities_Link = By.xpath("//a[text()='Careers']/following-sibling::a");
	public By UXDesigner_Link = By.xpath("(//div[@class='search-results__list']/div/div[contains(text(),'UX Designer')])[1]");
	
	public By FirstName_textBox = By.name("candidate_first_name");
	public By LastName_textBox = By.name("candidate_last_name");
	public By EmainId_textBox = By.name("candidate_email");
	public By PhoneNum_TextBox = By.name("candidate_phone");
	public By SubmitAppLicationYesIAgree_CheckBox = By.xpath("//input[contains(@id,'by_submitting_your_application')]/following-sibling::label");
	public By RecruitingProcessYesIAgree_CheckBox = By.xpath("//input[contains(@id,'recruiterbox_processes')]/following-sibling::label");
	public By Submit_Btn = By.name("_job_application_form");
	
	public KervDigital(WebDriver driver) {
		this.driver = driver;
	}
}
