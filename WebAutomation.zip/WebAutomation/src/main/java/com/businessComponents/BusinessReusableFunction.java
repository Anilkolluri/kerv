package com.businessComponents;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.testng.Assert;

import com.commonUtilities.CommonReusableFunctions;
import com.commonUtilities.ReadExcelData;
import com.pageElements.KervDigital;

public class BusinessReusableFunction extends CommonReusableFunctions {

	public void enterDetailsInToForm() throws Exception {
		
		KervDigital kervdigital = new KervDigital(driver);
		
		String parentWindow = driver.getWindowHandle();
		Set<String> s1 = driver.getWindowHandles();
		Iterator<String> i1 = s1.iterator();
		while (i1.hasNext()) {
			String ChildWindow = i1.next();
			if (!parentWindow.equalsIgnoreCase(ChildWindow)) {
				driver.switchTo().window(ChildWindow);
				ReadExcelData readexceldata = new ReadExcelData("candidateDetails.xlsx", "Sheet1");
				scrollToElement(kervdigital.FirstName_textBox);
				Thread.sleep(2000);
				SendTextIntoTextBox(kervdigital.FirstName_textBox, readexceldata.getCellData("FirstName", 1));
				Thread.sleep(2000);
				SendTextIntoTextBox(kervdigital.LastName_textBox, readexceldata.getCellData("LastName", 1));
				Thread.sleep(2000);
				SendTextIntoTextBox(kervdigital.EmainId_textBox, readexceldata.getCellData("Email", 1));
				Thread.sleep(2000);
				SendTextIntoTextBox(kervdigital.PhoneNum_TextBox, readexceldata.getCellData("Phone", 1));
				Thread.sleep(2000);
				clickElementUsingJS(By.xpath("//input[@id='resume']"));
				Thread.sleep(2000);
				uploadFile();
				Thread.sleep(2000);
				scrollToElement(kervdigital.SubmitAppLicationYesIAgree_CheckBox);
				clickElementUsingJS(kervdigital.SubmitAppLicationYesIAgree_CheckBox);
				Thread.sleep(2000);
				scrollToElement(kervdigital.RecruitingProcessYesIAgree_CheckBox);
				clickElementUsingJS(kervdigital.RecruitingProcessYesIAgree_CheckBox);
				Thread.sleep(2000);
				scrollToElement(kervdigital.Submit_Btn);
				clickElement(kervdigital.Submit_Btn);
				waitUntill_visibilityOfElement(By.xpath("//p[text()='Thank you for your application.']"), 20);
				boolean successMessage = driver.findElement(By.xpath("//p[text()='Thank you for your application.']")).isDisplayed();
				Assert.assertEquals(true, successMessage);
				
				driver.close();
			}
			
		}
		driver.switchTo().window(parentWindow);
		
	}
	
	public void uploadFile() throws AWTException {
		StringSelection ss = new StringSelection(System.getProperty("user.dir")+"\\src\\main\\java\\com\\testData\\resume.doc");
	     Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);

	     //imitate mouse events like ENTER, CTRL+C, CTRL+V
	     Robot robot = new Robot();
	     robot.delay(250);

	     //robot.keyPress(KeyEvent.VK_ENTER);
	    //robot.keyRelease(KeyEvent.VK_ENTER);
	     robot.keyPress(KeyEvent.VK_CONTROL);
	     robot.keyPress(KeyEvent.VK_V);
	     robot.keyRelease(KeyEvent.VK_V);
	     robot.keyRelease(KeyEvent.VK_CONTROL);
	     robot.keyPress(KeyEvent.VK_ENTER);
	     robot.delay(90);
	     robot.keyRelease(KeyEvent.VK_ENTER);
	}
}
