package testCases;

import java.io.IOException;
import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.businessComponents.BusinessReusableFunction;
import com.commonUtilities.ReadExcelData;
import com.pageElements.KervDigital;

public class WebSiteCorrectNess extends BusinessReusableFunction{
	KervDigital kervdigital = new KervDigital(driver);
	@BeforeTest
	public void setup() throws IOException {
		callBrowser();
	}
	
	@Test
	public void acceptCookiesWarning() throws IOException {
		clickElement(kervdigital.AcceptAll_Btn);
	}
	
	@Test
	public void careersPage() throws Exception {
		moveToElement(kervdigital.careers_MainLink);
		clickElement(kervdigital.JobOpportunities_Link);
		scrollToElement(kervdigital.UXDesigner_Link);
		waitUntill_elementIsClickable(kervdigital.UXDesigner_Link, 20);
		Thread.sleep(3000);
		clickUsingActionClass(kervdigital.UXDesigner_Link);
	}
	@Test
	public void fillDetails() throws Exception {
		enterDetailsInToForm();
	}
}
